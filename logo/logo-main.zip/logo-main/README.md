Repository for the Okchakko project logo.
